<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ',q8.xX2a o,J5aIt+>r+uO}Km}0<Evbi>_Oh(ciW$994#zOPOM^9iSkN  B]&pUm' );
define( 'SECURE_AUTH_KEY',   'uTvh]TW/A(EnzX$Zj9ux!RcB@hESQ}v#E61}I9]B.6#.y{X8V.+O;T;vR 6)?jL{' );
define( 'LOGGED_IN_KEY',     '0_Wqy+<x3(Y4L7iJ^X/5DA{P(fC>xrj _>yL(]A%z=2b4d!N:fi-R/,xV{B8?g?6' );
define( 'NONCE_KEY',         'WMh0sBCQb.Oz=+WB23~Uv{[%cE- ?/*aPAT_Jw-@U]Es:C?3fhgoZwc>JuBb9+DY' );
define( 'AUTH_SALT',         'DTJ.)0kV!JF=OtO>8|x!y~h]4;P4Lp5  aR&Ti(TDZAx+}O=Q:9N-BC-eK&3(^Kb' );
define( 'SECURE_AUTH_SALT',  'ZI#`)LD&%(.`rZZgq53)fB(D^3VYE9,gV$:jn#(MO=S@qF+/u)vUo=Et4TIM*P+!' );
define( 'LOGGED_IN_SALT',    '/4V*1w`ftG$_@Ai7c90Cj_%z=$2S4t2;WD{jBW7^-w_5ej*X2,o|6%.J>RYu{[9j' );
define( 'NONCE_SALT',        '#AxA=m{(f}p~U{2#z;M1WwH9oSUk4:=.0|GwBUl-5Bk`|SrZeBF*)_mcG9CFVG0F' );
define( 'WP_CACHE_KEY_SALT', 'gzKDw5_%aINYL:iSk8``ScrXA=DfUQ_wGa(ov%[dYW 58KylDw4/Pncl_b!R|c(F' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
